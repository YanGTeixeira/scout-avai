# Scout Avaí — Base inicial MongoDB

Data de referência da coleta: 2026-11-07

## Importação rápida
```bash
npm install
export MONGODB_URI="mongodb://127.0.0.1:27017"   # ou sua string do Atlas
export MONGODB_DB="scout_avai"
npm run seed:dry   # valida os arquivos, sem conectar
npm run seed       # cria coleções, validadores, índices e carrega os dados
```
Requer Node.js 18+. Com Node 20.6+ também funciona `node --env-file=.env seed.js` (copie `.env.example` para `.env`).

## O que o `seed.js` faz
1. Valida os JSONs (array, `_id` string, sem duplicados, referências entre coleções).
2. Cria as 16 coleções com validação `$jsonSchema` em modo **warn** (avisa, não bloqueia gravações).
3. Cria índices (incluindo únicos que protegem contra estatística duplicada por partida/provedor).
4. Faz upsert por `_id` — pode ser executado quantas vezes quiser.

### Modo seguro (padrão) × `--force`
- **Seguro:** na coleção `players`, só os campos vindos da página do clube (nome, número, posição, `sourceRefs`, `lastVerifiedAt`...) são atualizados. Campos que você preencher depois (`birthDate`, `contract`, `statistics`, `fullName`...) **não são sobrescritos**. Veja `MANAGED_FIELDS` em `schema.js`.
- **`--force`:** sobrescreve todos os campos presentes nos JSONs.
- O seed **não remove** atletas que saíram do clube; se rodar de novo com um elenco novo, revise quem deixou de constar na página oficial.

## Conteúdo (`data/`)
| Arquivo | Docs | Observação |
|---|---|---|
| `players.json` | 35 | Elenco profissional da página oficial em 2026-11-07 (nome, número, posição) |
| `clubs.json` | 4 | Avaí + 3 adversários citados no calendário |
| `stadiums.json` | 3 | Ressacada, CFA João Nilson Zunino, Adolfo Konder (desativado) |
| `competitions.json` / `seasons.json` | 5 / 1 | Série B, Série C, Catarinense, Recopa, Copa SC / Série B 2026 |
| `matches.json` | 3 | Rodadas 36–38 da Série B 2026 (uma encerrada, duas agendadas) |
| `club_titles.json` | 9 | Títulos e conquistas, com `count` conferido contra a contagem declarada |
| `club_history.json` | 11 | Fatos históricos do clube |
| `sources.json` | 4 | Catálogo de fontes (a CBF está marcada `usedInLoad: false`) |
| demais | 0 | Vazios, prontos para dados verificados |

## Convenções adicionais desta carga
- `positionLabel`: texto exato da página do clube. `positionGroup`: normalização minha (`GK`, `CB`, `FB`=lateral, `DM`=volante, `MF`=meio-campo, `FW`=atacante); não indica função tática.
- `matches.date` sempre existe; `kickoffAt` só quando o horário foi publicado (fuso `-03:00`). `stadiumId` ficou `null`: a página não informa o local.
- Datas parciais em `club_history`: `datePrecision` = `year` | `month` | `day`.
- `createdAt` / `updatedAt` (ISO) são adicionados pelo seed.

## Pontos a validar
- A página de história lista 19 títulos estaduais, **sem 1992 e 1999**, mas a página da Ressacada cita finais no estádio nessas datas (Brusque/1992, Figueirense/1999) sob "títulos ganhos na Ressacada". Mantive a lista de títulos oficial; confirme com o clube se essas finais foram ganhas ou perdidas.
- `América Mineiro`: UF deixada `null` (a página não informa).
- Sem dados da base (Sub-20/17/15), contratos, idades, pé dominante ou estatísticas: nada foi estimado.
- Revalide elenco e situação dos atletas antes de qualquer decisão.

## Fontes
- Avaí — elenco: https://avai.com.br/futebol/profissional/
- Avaí — história e títulos: https://avai.com.br/clube/historia/
- Avaí — Ressacada: https://avai.com.br/clube/ressacada/
- CBF — Série B 2026 (complementar, não usada): https://www.cbf.com.br/futebol-brasileiro/times/campeonato-brasileiro/serie-b/2026/20058?tab=atletas
